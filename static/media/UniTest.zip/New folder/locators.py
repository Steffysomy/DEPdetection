from selenium.webdriver.common.by import By
class MainPageLocators(object):
	GO_BUTTON=(By.ID, 'submit')
class SearchResultPageLocators(object):
	pass
